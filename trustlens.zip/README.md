# TrustLens: Phishing and Web Trust Analyzer

A single-page prototype that combines threat analysis, web security assessment, certificate and key validation, and community threat intelligence.

## Live demo
- Primary: https://trustlens.pages.dev
- Backup preview: https://claude.ai/artifact/2AptFuocVQ8AatDEVtaouG

## Problem
Phishing sites, fake recruitment portals, fraudulent payment links and weak trust infrastructure (such as CA key-generation flaws like the eMudhra TLS incident) are usually checked by separate tools. TrustLens brings the checks together in one place.

## Features
- **URL scan:** about 20 signals (typosquatting, homographs, risky TLDs, brand abuse, embedded redirects, double extensions, free hosting). Auto-scans on paste and gives a 0 to 100 risk score with a plain-language "what to do".
- **Certificate validation:** expiry, SAN mismatch, weak signature and key, self-signed, Certificate Transparency, editable CA watchlist.
- **Key analysis:** parses real PEM certificates and public keys in the browser. Checks key size, exponent, small factors, Fermat factorisation of close primes, ROCA-style fingerprint and bit randomness. Batch GCD across keys detects shared primes (weak key generation).
- **Header assessment:** HSTS, CSP, cookie flags, version disclosure, outdated software.
- **Community threat feed:** users report malicious domains; scans cross-check the feed.

## Run
No build step. Open `index.html` in any modern browser, or host the folder on any static host.

## Limitations (prototype)
- Certificates and headers are pasted in; they are not fetched live from the target.
- The threat feed is stored in the browser (localStorage).
- Scores are heuristic.

## Roadmap
FastAPI backend with live TLS handshake and CT log (crt.sh) lookups, ML classifier trained on PhishTank/OpenPhish, shared reports database with voting, browser extension.
